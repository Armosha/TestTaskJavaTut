package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;


public class MailPage {

    @FindBy(css = ".b-folders__folder__counters__total")
    public WebElement counter;

    WebDriver driver;

    public MailPage(WebDriver driver) {
        this.driver = driver;
    }

    public void checkLetters() {
        String letters = counter.getText().replace("/", "");
                System.out.println("Inbox includes: " + letters + " " + " letter(s)");
    }


}

