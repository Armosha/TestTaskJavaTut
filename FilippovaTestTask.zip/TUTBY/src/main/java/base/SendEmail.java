package base;

import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.io.UnsupportedEncodingException;
import java.util.Properties;

public class SendEmail {

    public static void main(String args[]) throws MessagingException, UnsupportedEncodingException {

        Properties p = System.getProperties();
        p.put("mail.smtp.socketFactory.port", 465);
        p.put("mail.smtp.port", 465);
        p.put("mail.smtp.host", "smtp.yandex.ru");
        p.put("mail.smtp.auth", "true");
        p.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory.class");


        Session session = Session.getDefaultInstance(p,

                new javax.mail.Authenticator() {
                    protected PasswordAuthentication getPasswordAuthentication() {
                        return new PasswordAuthentication("seleniumweb@tut.by", "12309876");
                    }});
        try {
            Message msg = new MimeMessage(session);
            msg.setFrom(new InternetAddress("seleniumweb@tut.by"));
            msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse("seleniumweb1@tut.by"));
            msg.setSubject("greeting");
            msg.setText("Hello, world, hello java!!");
            Transport.send(msg);
            System.out.println("Done!");

        } catch (Exception e) {
            System.out.println("Something wrong" + " " + e);
        }
    }
}

