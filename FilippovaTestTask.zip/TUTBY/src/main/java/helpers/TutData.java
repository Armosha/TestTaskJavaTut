package helpers;

import org.testng.annotations.DataProvider;


public class TutData {
    @DataProvider(name = "logindata")
    public static Object[][] pages() {
        return new Object[][]{
                {"seleniumweb", "12309876"},
                {"seleniumweb1","123zxcvb" }
        };
    }
}
