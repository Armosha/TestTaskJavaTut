import base.TestBase;
import helpers.TutData;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;
import pages.LoginPage;
import pages.MailPage;

import static org.testng.Assert.assertTrue;



public class TutPageTest extends TestBase {

    @Test(dataProvider = "logindata", dataProviderClass = TutData.class)
    public void checkTuTby(String name, String pass) {
        LoginPage loginPage = PageFactory.initElements(driver, LoginPage.class);
        MailPage mailPage = PageFactory.initElements(driver, MailPage.class);
        logger.debug("Login with logindata, click enter button");
        loginPage.loginAs(name, pass);
        logger.debug("check all letters");
        mailPage.checkLetters();
        logger.info("check Title");
        assertTrue(driver.getTitle().contains("Входящие — Яндекс.Почта"));
        logger.debug("Assert's successful");

    }

}